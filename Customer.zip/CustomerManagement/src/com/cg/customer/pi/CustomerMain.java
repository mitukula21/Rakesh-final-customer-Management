package com.cg.customer.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.service.CustomerServiceImpl;

public class CustomerMain {

	static Scanner sc = new Scanner(System.in);
	
	static CustomerServiceImpl custServiceImpl = null;
	
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws CustomerException {
		PropertyConfigurator.configure("resources//log4j.properties");
		CustomerBean customer = null;
boolean result;
boolean b=false;
		String custId = null;
		int option = 0;
		
	try {
		
		System.out.println("Enter UserName: ");
		String user=sc.next();
		System.out.println("Enter password: ");
		String pass=sc.next();
		
		custServiceImpl = new CustomerServiceImpl();
		
		
	String old=	custServiceImpl.logIn(user);
		
		
		if(old.equals(pass))
		{
	System.out.println("...LOGIN SUCCESSFUL...");

		while(true){

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   CUSTOMER MANAGEMENT SYSTEM ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Customer Page ");
			System.out.println("2.Update/Edit Customer Page");
			System.out.println("3.Customer Listing  Page");
			System.out.println("4.Delete Customer Page");
			System.out.println("5.Exit Application");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (customer == null) {
						customer = populateCustomerBean();
						       
					}

					try {
						
						custId = custServiceImpl.addCustomerDetails(customer);

						System.out.println("Customer details  has been successfully registered ");
						System.out.println("Customer  ID Is: " + custId);
						int cus=Integer.parseInt(custId);
						customer.setCustId(cus);
					
					} catch (CustomerException CustException) {
						logger.error("exception occured", CustException);
						System.err.println("ERROR : "+ CustException.getMessage());
					} finally {
						custId = null;
						custServiceImpl = null;
						customer = null;
					}
        
					break;

				case 2:
   try {
					
	              Scanner scan=new Scanner(System.in);
					
				CustomerBean customer1=	new CustomerBean();
					 CustomerServiceImpl custServiceImpl =new CustomerServiceImpl();
				//	 Scanner scann=new Scanner(System.in);
					System.out.println("Enter Custid to be edit");
					int cid=scan.nextInt();
					while(true)
					{
						String cust=Integer.toString(cid);
						result=custServiceImpl.isValidId(cust);
						if(result==true)
						{
						
							customer1.setCustId(cid);
						break;
						}
						else
						{
							System.err.println("id must be integer ");
							System.out.println("Enter Correct id: ");
							 cid=scan.nextInt();
					
						    }
						}
				
					System.out.println("Enter Cust Name to be edit");
					
					Scanner scan1=new Scanner(System.in);
					
					String name=scan1.nextLine();
					
				
					
					/*while(true)
					{
					//System.out.println(12345);	
						
				 result=custServiceImpl.isValidName(name);
						if(result==true)
						{
						customer1.setCustName(name);
						
						
						break;
						}
						else
						{
							System.err.println("name should be in between 3 to 10  characters ");
							System.out.println("Enter Correct name: ");
							 name=scan1.nextLine();
						}
					
					
					}*/
					
					System.out.println("Enter Cust Email to be edit");
					Scanner scan8=new Scanner(System.in);
					String mail=scan8.next();
					
					while(true)
					{
						
						result=custServiceImpl.isValidEmailId(mail);
						if(result==true)
						{
							customer1.setEmailId(mail);
							break;
						}
						else
						{
							System.err.println("Enter Correct Email format ");
							System.out.println("Enter Correct EmailId: ");
							 mail=scan8.next();
						}
					}
					
					
					
					
					System.out.println("Enter Cust password to be edit");
					Scanner scan3=new Scanner(System.in);
					String password=scan3.nextLine();
					
					
					
					while(true)
					{
						result=custServiceImpl.isValidPassword(password);
						if(result==true)
						{
							customer1.setPassword(password);
							break;
						}
						else
						{
							System.err.println("Start With Capital letter only, ");
							System.out.println("Enter Correct Password: ");
							 password=scan3.nextLine();
						}
					}
					
					
					
					
					System.out.println("Enter Cust PhNo to be edit");
					Scanner scan7=new Scanner(System.in);
					String phno=scan7.nextLine();
					
					
				while(true)
				{
					
				
				
				result=custServiceImpl.isValidPhoneNumber(phno);
				
				
				if(result==true)
				{
					customer1.setPhNo(phno);
					break;
				}
				else
				{
					System.err.println("Phone Number contains 10 digits only, ");
					System.out.println("Enter Correct PhoneNumber: ");
					 phno=scan7.nextLine();
				}
				}
					
					
					
					
				
					System.out.println("Enter Cust Address to be edit");
					Scanner scan4=new Scanner(System.in);
					String addr=scan4.nextLine();
					
					System.out.println("Enter Cust City to be edit");
					Scanner scan5=new Scanner(System.in);
					String city=scan5.nextLine();
					
					
					System.out.println("Enter Cust Zipcode to be edit");
					int code=scan.nextInt();
					
					
					
					while(true)
					{
						String code1=Integer.toString(code);
						result=custServiceImpl.isValidZipCode(code1);
						if(result==true)
						{
						
							customer1.setZipcode(code);
						break;
						}
						else
						{
							System.err.println("Zipcode contains 6 digits only, ");
							System.out.println("Enter Correct Zipcode: ");
							 code=scan.nextInt();
					
						}
						}
					
					
					
					System.out.println("Enter Cust Country to be edit");
					Scanner scan6=new Scanner(System.in);
					String country=scan6.nextLine();


					
					
					custServiceImpl.editCustomerDetails(cid,name,mail,password,phno,addr,city,code,country);
					
					
					System.out.println("updated Successfuly");
						
            }catch(CustomerException custException) {
		
		    logger.error("Enter Correct Id:", custException);
		       System.err.println("ERROR : "+ custException.getMessage());
	}
				
					break;

					
					
					
				case 3:

					custServiceImpl = new CustomerServiceImpl();
					try {
						List<CustomerBean> customerList = new ArrayList<CustomerBean>();
						customerList = custServiceImpl.retriveAll();
 
						if (customerList != null)
						{
							Iterator<CustomerBean> i = customerList.iterator();
							if(i.hasNext())
							{
 
							System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
							System.out.printf("%10s %30s %20s %20s %20s %20s %20s %20s %20s %20s","CUSTID","FULLNAME","EMAIL","PASSWORD","PHNO","ADDRESS","CITY","ZIPCODE","COUNTRTY","REGESTRATION-DATE");
							System.out.println();
							System.out.println("-------------------------------------------------------------------------------------------------------------------------------------");
							for(CustomerBean customer1: customerList)
							//while (i.hasNext())
							{
								System.out.format("%10s %30s %20s %20s %20s %20s %20s %20s %20s %20s",customer1.getCustId(),customer1.getCustName(),customer1.getEmailId(),customer1.getPassword(),customer1.getPhNo(),customer1.getAddr(),customer1.getCity(),customer1.getZipcode(),customer1.getCountry(),customer1.getDate());
								System.out.println();
							}
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------");
							}
						}
 
 
							else {
							System.out.println("NO DETAILS FOUND");
						}
 
					}
 
					catch (CustomerException e) {
 
						System.out.println("Error  :" + e.getMessage());
					}
					 
					break;
				case 4:
					try {
					
					CustomerBean customer2=new CustomerBean();
					System.out.println("Enter Customer id to be Deleted");
					int cid1=sc.nextInt();
		
					
					custServiceImpl.deleteCustomerDetails(cid1);
					

					
					
					System.out.println("deleted Successfully");
					}catch(CustomerException customerException) {
						
						logger.error("Enter Correct Id:", customerException);
						System.err.println("ERROR : "+ customerException.getMessage());
					}
					
					
					break;
				
					
					
					
				case 5:

					System.out.print("Exit customer Application");
					System.exit(0);
					
					break;
				default:
					System.out.println("Enter a valid option[1-5]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
			
			/*System.out.println("Do you want to Continue? yes/no");
			String str=sc.next();
			if(str.equals("yes"))
			{
				b=true;
			}
			else
			{
				System.out.println("Thank You");
				b=false;
			}*/
			
			
			
		}
		//while(b);
		
		}
		
	
	else
		{
			System.err.println("enter correct details");
		}
		}
	catch(Exception e)
		{
			System.err.println("Enter Correct Details");
		}
		
		}
	
	private static CustomerBean populateCustomerBean() {

		/****
		 Reading and setting the values for the CustomerBean
		 
		 
		*******/
		

		CustomerBean customer = new CustomerBean();

		
		boolean result;
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter Customer Full name: ");
	
		String name=sc1.nextLine();
		
		/*
		while(true)
		{
	 result=custServiceImpl.isValidName(name);
			if(result==true)
			{
			
				customer.setCustName(name);
			break;
			}
			else
			{
				System.out.println("name should be in between 3and 10 characters ");
				System.out.println("Enter Correct name: ");
				 name=sc1.nextLine();
			}
			}*/
		System.out.println("Enter Email Id: ");
		
		Scanner scanner= new Scanner(System.in);
		String mail=scanner.next();
		while(true)
		{
			result=custServiceImpl.isValidEmailId(mail);
			if(result==true)
			{
				customer.setEmailId(mail);
				break;
			}
			else
			{
				System.err.println("Enter Correct Email format ");
				System.out.println("Enter Correct EmailId: ");
				 mail=sc.next();
			}
		}
		
		System.out.println("Enter password: ");
		Scanner scanner2= new Scanner(System.in);
		String password=scanner2.next();
		while(true)
		{
			result=custServiceImpl.isValidPassword(password);
			if(result==true)
			{
				customer.setPassword(password);
				break;
			}
			else
			{
				System.err.println("Start With Capital letter only, ");
				System.out.println("Enter Correct Password: ");
				 password=sc.next();
			}
		}
		

		System.out.println("Enter phone number: ");
		Scanner scanner1= new Scanner(System.in);
		String phno=scanner1.next();
		
			while(true)
		{
			
		
		
		result=custServiceImpl.isValidPhoneNumber(phno);
		if(result==true)
		{
			customer.setPhNo(phno);
			break;
		}
		else
		{
			System.err.println("Phone Number contains 10 digits only, ");
			System.out.println("Enter Correct PhoneNumber: ");
			 phno=sc.next();
		}
		}
		


		Scanner sc2= new Scanner(System.in);
		System.out.println("Enter customer address: ");
		customer.setAddr(sc2.nextLine());	
		Scanner sc3 = new Scanner(System.in);
		System.out.println("Enter city: ");
		customer.setCity(sc3.nextLine());

		System.out.println("Enter Zipcode: ");
		int code=sc.nextInt();
		
		while(true)
		{
			String code1=Integer.toString(code);
			result=custServiceImpl.isValidZipCode(code1);
			if(result==true)
			{
			
				customer.setZipcode(code);
			break;
			}
			else
			{
				System.err.println("Zipcode contains 6 digits only, ");
				System.out.println("Enter Correct Zipcode: ");
				 code=sc.nextInt();
		
			}
			}
		
		System.out.println("Enter country: ");
		customer.setCountry(sc.next());

		custServiceImpl = new CustomerServiceImpl();

		try {
			custServiceImpl.validateCustomer(customer);
			return customer;
		} catch (CustomerException custException) {
			logger.error("exception occured", custException);
			System.err.println("Invalid data:");
			System.err.println(custException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
	




	
}
