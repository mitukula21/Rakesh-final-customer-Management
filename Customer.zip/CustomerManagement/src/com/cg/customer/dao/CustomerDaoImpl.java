package com.cg.customer.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.util.DBConnection;


public class CustomerDaoImpl implements ICustomerDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public CustomerDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	
	
	//------------------------ 1. Customer Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addCustDetails(custBean cust)
		 - Input Parameters	:	custBean cust
		 - Return Type		:	String
		 - Throws			:  	CustomerException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	17/06/2019
		 - Description		:	Adding cust
		 ********************************************************************************************************/
	


	public String addCustomerDetails(CustomerBean customer) throws CustomerException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String custId=null;
		
		int queryResult=0;
		System.out.println("connected");
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,customer.getCustName());			
			preparedStatement.setString(2,customer.getEmailId());
			preparedStatement.setString(3,customer.getPassword());
			preparedStatement.setString(4,customer.getPhNo());
			preparedStatement.setString(5,customer.getAddr());
			preparedStatement.setString(6,customer.getCity());
			preparedStatement.setInt(7,customer.getZipcode());
			preparedStatement.setString(8,customer.getCountry());
		
					
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				custId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustomerException("Inserting customer details failed ");

			}
			else
			{
				logger.info("customer details added successfully:");
				return custId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		
	}

	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	editCustDetails(int custid,String fname,String eid)
	 - Input Parameters	:	CustomerBean cust
	 - Return Type		:	CustomerBean
	 - Throws			:  	CustomerException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	17/06/2018
	 - Description		:	Updating cust
	 ********************************************************************************************************/
	
	
	
	public CustomerBean editCustomerDetails(int custid,String fname,String eid,String password,String phone,String addr,String city,int zip,String country) throws CustomerException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		int resultset ;
		CustomerBean bean=null;
		
		try
		{
			
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_UPDATE_QUERY);
			preparedStatement.setString(1,fname);
			
			preparedStatement.setString(2,eid);
			preparedStatement.setString(3,password);
			preparedStatement.setString(4,phone);
			preparedStatement.setString(5,addr);
			preparedStatement.setString(6,city);
			preparedStatement.setInt(7,zip);
			preparedStatement.setString(8,country);
			
			preparedStatement.setInt(9,custid);
			resultset=preparedStatement.executeUpdate();
	if(resultset==0)
			throw new CustomerException("Id doesn't Exist");
			
			
		}
			
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustomerException("Id doesn't Exist");
		}
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		return bean;
		
	}

	
	//------------------------ 1. Customer Application --------------------------
		/*******************************************************************************************************
		 - Function Name	:	retriveAllDetails
		 - Input Parameters	:	CustomerBean cust
		 - Return Type		:	CustomerBean
		 - Throws			:  	CustomerException
		 - Author			:	CAPGEMINI
		 - Creation Date	:	17/06/2018
		 - Description		:	retriving All Customers Details
		 ********************************************************************************************************/
	

	public List<CustomerBean> retriveAllDetails() throws CustomerException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int custCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CustomerBean> custList=new ArrayList<CustomerBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CustomerBean bean=new CustomerBean();
				bean.setCustId(resultset.getInt(1));
				bean.setCustName(resultset.getString(2));
				bean.setEmailId(resultset.getString(3));
				bean.setPassword(resultset.getString(4));
				bean.setPhNo(resultset.getString(5));
				bean.setAddr(resultset.getString(6));
				bean.setCity(resultset.getString(7));
				bean.setZipcode(resultset.getInt(8));
				bean.setCountry(resultset.getString(9));
				bean.setDate(resultset.getDate(10));
				
				
				custList.add(bean);
				
				custCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		if( custCount == 0)
			return null;
		else
			return custList;
	}


	
	//------------------------ 1. Customer Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteCustDetails(String id1)
	 - Input Parameters	:	CustomerBean cust
	 - Return Type		:	CustomerBean
	 - Throws			:  	CustomerException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	17/06/2018
	 - Description		:	delete Customer Details
	 ********************************************************************************************************/
	


	public CustomerBean deleteCustomerDetails(String id1) throws CustomerException{

		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		int resultset ;
		CustomerBean bean=null;
		try
		{
			int id=Integer.parseInt(id1);
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DELETE_QUERY);
			preparedStatement.setInt(1,id);
		
			resultset=preparedStatement.executeUpdate();
			
			if(resultset==0)
			{
				//System.out.println("deleted Successfully");
				throw new CustomerException("deleted id not found");
				
			}
			
			}catch (Exception sqlException) {
				logger.error(sqlException.getMessage());
				
				throw new CustomerException("deleted id not found");
			}
		
		
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		
		}
	
			return bean;
	
		
		
		
	}




	public String logIn(String user) throws CustomerException {
Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		CustomerBean bean=null;
		String old=null;
		try
		{
			
			preparedStatement=connection.prepareStatement(QueryMapper.LOGIN_QUERY);
			preparedStatement.setString(1,user);
			resultset=preparedStatement.executeQuery();
			while(resultset.next())
			{
				 old = resultset.getString(1);
			}
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustomerException(e.getMessage());
		
			
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		return old;
	}




	










	

}
