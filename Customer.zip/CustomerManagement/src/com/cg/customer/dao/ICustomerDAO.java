package com.cg.customer.dao;

import java.util.List;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.exception.CustomerException;

public interface ICustomerDAO 
{
	public String addCustomerDetails(CustomerBean cust) throws CustomerException;
	public CustomerBean editCustomerDetails(int custid,String fname,String eid,String password,String phone,String addr,String city,int zip,String country) throws CustomerException;
	public List<CustomerBean> retriveAllDetails()throws CustomerException;
	public CustomerBean deleteCustomerDetails(String id1) throws CustomerException;
}
