package com.cg.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.dao.ICustomerDAO;
import com.cg.customer.exception.CustomerException;

public class CustomerServiceImpl implements ICustomerService{
	
	ICustomerDAO custDao;

	public String addCustomerDetails(CustomerBean cust) throws CustomerException {
		custDao=new CustomerDaoImpl();	
		String custSeq;
		custSeq= custDao.addCustomerDetails(cust);
		return custSeq; 
	}

	
	public CustomerBean editCustomerDetails(int custid,String Fname,String eid,String password,String phone,String addr,String city,int zip,String country) throws CustomerException {
		CustomerDaoImpl custDao=new CustomerDaoImpl();
		//int id=Integer.parseInt(custid);
		CustomerBean bean=null;
		bean=custDao.editCustomerDetails(custid,Fname,eid,password,phone,addr,city,zip,country);
		return bean;
	}

	
	public List<CustomerBean> retriveAll() throws CustomerException {
		custDao=new CustomerDaoImpl();
		List<CustomerBean> custList=null;
		custList=custDao.retriveAllDetails();
		return custList;
	}
	
	
	public CustomerBean deleteCustomerDetails(int custid) throws CustomerException {
		CustomerDaoImpl custDao=new CustomerDaoImpl();
		String id=Integer.toString(custid);
		CustomerBean bean=null;
		 bean=custDao.deleteCustomerDetails(id);
		return bean;
	}



		
	
	
	public void validateCustomer(CustomerBean bean) throws CustomerException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPhNo()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		
		if(!validationErrors.isEmpty())
			throw new CustomerException(validationErrors +"");
	}

	/*public boolean isValidName(String custName){
		
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,20}$");
		Matcher nameMatcher=namePattern.matcher(custName);
		System.out.println(nameMatcher.matches());
		if(nameMatcher.matches())
			return true;
		else
			
			return false;
	}*/
	
	
	public boolean isValidZipCode(String code) {
		
	Pattern namepattern = Pattern.compile("^[0-9]{6}$");
		 
		
		    Matcher matcher = namepattern.matcher(code);
		   if(matcher.matches())
		    
		    	
		    return true;
		    else 
		    	return false;
	

	}
	
	public boolean isValidPhoneNumber(String number){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(number);
		if(phoneMatcher.matches())
			return true;
		else 
			return false;
		
	}
	
	


	public String logIn(String user) throws CustomerException {
		CustomerDaoImpl custDao=new CustomerDaoImpl();
		String old=custDao.logIn(user);
		return old;
		
	}


	public boolean isValidEmailId(String mail) {
		
		Pattern emailPattern = Pattern.compile("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$");
		Matcher emailMatcher = emailPattern.matcher(mail);
		
		if(emailMatcher.matches())
			return true;
		else
			
			return false;	
	}


	public boolean isValidPassword(String password) {
		
		Pattern emailPattern = Pattern.compile("[A-Z][A-Za-z]{2,}$");
		Matcher emailMatcher = emailPattern.matcher(password);
		
		if(emailMatcher.matches())
			return true;
		else
			
			return false;
	}


	public boolean isValidId(String cid) {
		
		Pattern idpattern = Pattern.compile("^[0-9]{1,5}$");
		 
		
	    Matcher matcher = idpattern.matcher(cid);
	  
	   if(matcher.matches())
	    
	    	
	    return true;
	    else 
	    	
	    	System.out.println("yes");
	    	return false;
	}


	




	
	


	


	


	



	
}

	
	


