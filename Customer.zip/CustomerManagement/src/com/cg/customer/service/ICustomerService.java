package com.cg.customer.service;

import java.util.List;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.exception.CustomerException;

public interface ICustomerService 
{
	public String addCustomerDetails(CustomerBean customer) throws CustomerException;
	public CustomerBean editCustomerDetails(int custid,String fname,String eid,String password,String phone,String addr,String city,int zip,String country) throws CustomerException ;
	public List<CustomerBean> retriveAll()throws CustomerException;
	public CustomerBean deleteCustomerDetails(int custid) throws CustomerException;
	public void validateCustomer(CustomerBean bean) throws CustomerException;
}
