package com.cg.customer.bean;

import java.util.Date;


public class CustomerBean 
{
	private int custId;
	private String custName;
	private String emailId;
	private String password;
	private String phNo;
	private String addr;
	
	private String city;
	private int zipcode;
	private String country;
	private Date date;
	
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhNo() {
		return phNo;
	}
	public void setPhNo(String phNo) {
		this.phNo =  phNo;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "custId=" + custId + ", custName=" + custName + ", emailId=" + emailId + ", password="
				+ password + ", phNo=" + phNo + ", addr=" + addr + ", city=" + city + ", zipcode=" + zipcode
				+ ", country=" + country + ", date=" + date + "";
	}
	
	
	

	

	



public CustomerBean()
{
	super();
}

public CustomerBean (int custId,String custName,String emailId,String Password,String Phno,String addr,String city,int Zipcode,String Country, Date date)
{
	super();
	this.custId=custId;
	this.custName=custName;
	this.emailId=emailId;
	this.password=password;
	this.phNo=phNo;
	this.addr=addr;
	this.city=city;
	this.zipcode=zipcode;
	this.country=country;
	this.date=date;

}
}
