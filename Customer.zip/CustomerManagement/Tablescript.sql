create table patient1(custid number,
custName varchar2(20),emailId varchar2(20),Password varchar2(20),phNo number(10),address varchar2(20),city varchar2(20),
Zipcode number(6),Country varchar2(20),Date date);

 create sequence custid_sequence start with 10;