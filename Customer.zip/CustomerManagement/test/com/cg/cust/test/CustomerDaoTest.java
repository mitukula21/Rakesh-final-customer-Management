package com.cg.cust.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.exception.CustomerException;

public class CustomerDaoTest {

	static CustomerDaoImpl dao;
	static CustomerBean customer;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new CustomerDaoImpl();
		customer = new CustomerBean();
	}

	@Test
	public void testAddCustDetails() throws CustomerException {

		assertNotNull(dao.addCustomerDetails(customer));

	}

	/************************************
	 * Test case for addCustDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddCustDetails1() throws CustomerException {
		// increment the number next time you test for positive test case
		assertEquals(60, dao.addCustomerDetails(customer));
	}

	/************************************
	 * Test case for addCustDetails()
	 * 
	 ************************************/

	@Test
	public void testAddCustDetails2() throws CustomerException {

		customer.setCustName("rakesh");
		customer.setPhNo("9912109318");
		customer.setEmailId("rakesh@gmail.com");
		customer.setZipcode(123456);
		assertNotNull("93", dao.addCustomerDetails(customer));
//		assertNotNull("Data Inserted successfully",
//				Integer.parseInt(dao.addCustDetails(cust)) > 1000);

	}

	/********************************************
	 * Test case for retriveAllDetails()
	 ***********************************************/
	@Test
	public void testViewAll() throws CustomerException {
		assertNotNull(dao.retriveAllDetails());
	}

	/****************************************************
	 * Test case for viewById()
	 ******************************************************/

	@Test
	public void testById() throws CustomerException {
		assertNotNull(dao.editCustomerDetails(91,"rakesh","rakesh@gmail.com","Rakesh","9866456285","hyderabad","hyderabad",123456,"india"));
	}

	@Ignore
	@Test
	public void testById1() throws CustomerException {
		assertEquals("TestName", dao.editCustomerDetails(91,"rakesh","rakesh@gmail.com","Rakesh","9866456285","hyderabad","hyderabad",123456,"india").getCustName());
	}

}
